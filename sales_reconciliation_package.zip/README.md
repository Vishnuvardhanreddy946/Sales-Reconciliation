# Daily Sales & Cash Reconciliation Automation

## Overview
This project automates the process of recording daily sales and reconciling cash for a retail store using Google Sheets and Google Apps Script.

## Features
- Auto-calculates Expected Cash and Difference
- Highlights discrepancies > ₹50
- Sends daily reminder email if today's entry is missing
- Generates and emails a monthly PDF report

## Setup Instructions
1. Create a new Google Sheet.
2. Import `Daily_Sales_Log.csv` into a tab named **Daily_Sales_Log**.
3. Import `Settings.csv` into a tab named **Settings**.
4. Set up Data Validation for Store Name column using `Settings` tab.
5. Apply conditional formatting:
   - Red if `ABS(Difference) > 50`
   - Green otherwise
6. Go to **Extensions → Apps Script**, paste the code from `apps_script_code.gs`.
7. Set up triggers:
   - `dailyReminder` → Time-driven → Every day at 10 PM
   - `monthlyReport` → Time-driven → 1st of month at 9 AM

## Flow Diagram
Staff Entry → Google Sheet Log → Auto Reconciliation → (Highlight Errors / Daily Reminder Email / Monthly PDF Report)

## Sample Output
Daily Email:
```
Subject: Daily Sales Reconciliation – 11 Aug 2025
Store: Store A
POS Total: ₹25,000 | Expected Cash: ₹15,000 | Counted Cash: ₹14,950 | Difference: -₹50
Status: Small shortage
```

## Prompt Appendix (if AI used)
Prompts and outputs would be listed here if AI summaries are integrated.

## Limitations
- Requires manual entry of daily sales data
- Gmail quota limits for sending emails
